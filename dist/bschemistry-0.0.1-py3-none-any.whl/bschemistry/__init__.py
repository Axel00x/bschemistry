class console:
    def __init__(self):
        self.name = "Test"
    
    def sayHi(self):
        print(self.name)