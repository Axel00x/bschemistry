import main as m

t = m.Table()

elem = m.format("{1}H2O")

print(m.calc_mass(elem))