from . import table

def calc_mass(elem):
    mass = 0
    for molec in elem.keys():
        for i in range(int(molec)):
            for atom in elem[molec].keys():
                if atom not in table.table:
                    raise ValueError(f"Element {atom} not found in the periodic table")
                mass += table.elem(atom).a_mass * elem[molec][atom]
    
    return mass