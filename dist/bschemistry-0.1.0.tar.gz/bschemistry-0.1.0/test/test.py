import main as m

t = m.Table()

print(t.elem("O").name)